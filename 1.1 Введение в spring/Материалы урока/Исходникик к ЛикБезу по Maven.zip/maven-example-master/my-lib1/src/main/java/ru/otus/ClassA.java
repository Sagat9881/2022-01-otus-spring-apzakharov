package ru.otus;

public class ClassA {
    public static void f() {
        System.out.println("ClassA v1");
    }
}

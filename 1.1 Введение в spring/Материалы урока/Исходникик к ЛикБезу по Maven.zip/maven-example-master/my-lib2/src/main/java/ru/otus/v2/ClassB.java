package ru.otus.v2;

public class ClassB {
    public void f() {
        System.out.println("ClassA v2");
    }
}

package ru.otus;

public class LibClass {
    public static void print() {
        ru.otus.ClassA.f();
    }
}
